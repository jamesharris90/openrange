// API Configuration
const CONFIG = {
    // Dynamic API base URL (handles localhost vs production)
    API_BASE: location.hostname === 'localhost' 
        ? 'http://localhost:8080' 
        : window.location.origin,
    
    // Saxo API Configuration (LIVE ACCOUNT)
    SAXO: {
        environment: 'live',
        apiUrl: 'https://gateway.saxobank.com/openapi',
        accountNumber: '21865300',
        clientKey: 'iPB-4ci3kYbv3qeSz8MBvg==',
        token: 'eyJhbGciOiJFUzI1NiIsIng1dCI6IjY3NEM0MjFEMzZEMUE1OUNFNjFBRTIzMjMyOTVFRTAyRTc3MDMzNTkifQ.eyJvYWEiOiI3Nzc3NSIsImlzcyI6Im9hIiwiYWlkIjoiMTA5IiwidWlkIjoiaVBCLTRjaTNrWWJ2M3FlU3o4MUJ2Zz09IiwiY2lkIjoiaVBCLTRjaTNrWWJ2M3FlU3o4MUJ2Zz09IiwiaXNhIjoiRmFsc2UiLCJ0aWQiOiIyMDAyIiwic2lkIjoiNDU0ZWI2OWI2NmQ1NDJkY2JkNzljYmZhYWQzNWQwYmMiLCJkZ2kiOiI4NCIsImV4cCI6IjE3NzAwMzYyNzUiLCJvYWwiOiIxRiIsImlpZCI6Ijk2OTM3MmQ5MmEzMDQ0Njg0Zjg5MDhkZTVmZmFiMmVlIn0.wNWzuOy9baHyIWkeqwplQZsIdRCdj6cl76-mGfagSaILSlUZTjALtoLXFYbxoXa-dr-wJzg-2bBAmkWfz8W-1w'
    },
    
    // Currency conversion (EUR to GBP - update regularly)
    EUR_TO_GBP: 0.85,
    
    // Display preferences
    DISPLAY_CURRENCY: 'GBP',
    CURRENCY_SYMBOL: '£',
    
    // Cache settings
    NEWS_CACHE_DURATION: 5 * 60 * 1000, // 5 minutes
    
    // API Timeouts
    REQUEST_TIMEOUT: 10000 // 10 seconds
};
